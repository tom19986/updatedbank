package com.onlinebanking.user;

import com.onlinebanking.user.model.Role;
import com.onlinebanking.user.model.User;
import com.onlinebanking.user.repository.UserRepository;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Page;

import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

@SpringBootTest
public class UserRepositoryTest {

    @Autowired
    private UserRepository userRepository;

    private User testUser1;
    private User testUser2;

    @BeforeEach
    public void setUp() {
        // Initialize and save test users
        testUser1 = new User();
        testUser1.setUsername("testuser");
        testUser1.setPhoneNumber("1234567890");
        testUser1.setFirstName("John");
        testUser1.setEmail("john@example.com");
        testUser1.setRole(Role.USER);
        userRepository.save(testUser1);

        testUser2 = new User();
        testUser2.setUsername("adminuser");
        testUser2.setPhoneNumber("0987654321");
        testUser2.setFirstName("Jane");
        testUser2.setEmail("jane@example.com");
        testUser2.setRole(Role.ADMIN);
        userRepository.save(testUser2);
    }

    @AfterEach
    public void tearDown() {
        // Clean up test data
        userRepository.deleteAll();
    }

    @Test
    public void testFindByUsername() {
        User foundUser = userRepository.findByUsername(testUser1.getUsername());
        assertNotNull(foundUser);
        assertEquals(testUser1.getUsername(), foundUser.getUsername());
    }

    @Test
    public void testFindByPhoneNumber() {
        User foundUser = userRepository.findByPhoneNumber(testUser1.getPhoneNumber());
        assertNotNull(foundUser);
        assertEquals(testUser1.getPhoneNumber(), foundUser.getPhoneNumber());
    }

    @Test
    public void testFindByFirstName() {
        User foundUser = userRepository.findByFirstName(testUser1.getFirstName());
        assertNotNull(foundUser);
        assertEquals(testUser1.getFirstName(), foundUser.getFirstName());
    }

    @Test
    public void testFindByEmail() {
        User foundUser = userRepository.findByEmail(testUser1.getEmail());
        assertNotNull(foundUser);
        assertEquals(testUser1.getEmail(), foundUser.getEmail());
    }

    @Test
    public void testExistsByUsername() {
        boolean exists = userRepository.existsByUsername(testUser1.getUsername());
        assertTrue(exists);
    }

    @Test
    public void testExistsByEmail() {
        boolean exists = userRepository.existsByEmail(testUser1.getEmail());
        assertTrue(exists);
    }

    @Test
    public void testFindByRole() {
        List<User> users = userRepository.findByRole(testUser1.getRole());
        assertFalse(users.isEmpty());
        assertEquals(testUser1.getRole(), users.get(0).getRole());
    }

    @Test
    public void testFindByRoleIn() {
        Pageable pageable = PageRequest.of(0, 10);
        Page<User> usersPage = userRepository.findByRoleIn(List.of(testUser1.getRole(), testUser2.getRole()), pageable);
        assertTrue(usersPage.hasContent());
        assertTrue(usersPage.getContent().size() >= 2);
    }

    @Test
    public void testFindByUsernameContainingIgnoreCase() {
        Pageable pageable = PageRequest.of(0, 10);
        Page<User> usersPage = userRepository.findByUsernameContainingIgnoreCase("test", pageable);
        assertTrue(usersPage.hasContent());
        assertEquals("testuser", usersPage.getContent().get(0).getUsername());
    }

    @Test
    public void testFindByEmailContainingIgnoreCase() {
        Pageable pageable = PageRequest.of(0, 10);
        Page<User> usersPage = userRepository.findByEmailContainingIgnoreCase("john", pageable);
        assertTrue(usersPage.hasContent());
        assertEquals("john@example.com", usersPage.getContent().get(0).getEmail());
    }

    @Test
    public void testFindByPhoneNumberContainingIgnoreCase() {
        Pageable pageable = PageRequest.of(0, 10);
        Page<User> usersPage = userRepository.findByPhoneNumberContainingIgnoreCase("123", pageable);
        assertTrue(usersPage.hasContent());
        assertEquals("1234567890", usersPage.getContent().get(0).getPhoneNumber());
    }

}
