-- SQL script to create the 'users' table

CREATE TABLE users (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(255) UNIQUE NOT NULL,
    password VARCHAR(255) NOT NULL,
    firstName VARCHAR(255),
    lastName VARCHAR(255),
    phoneNumber VARCHAR(20),
    email VARCHAR(255) UNIQUE,
    role VARCHAR(50), -- Assuming role is stored as a string
    gender VARCHAR(50), -- Assuming gender is stored as a string
    isBlock BOOLEAN DEFAULT FALSE,
    registerDate TIMESTAMP,
    lastLoginDate TIMESTAMP,
    isLogin BOOLEAN DEFAULT FALSE,
    lastUpdatedDate TIMESTAMP,
    invalidAttemptCount INT DEFAULT 0
);

