-- SQL script to create the 'banktransactions' table

CREATE TABLE banktransactions (
    transactionId BIGINT AUTO_INCREMENT PRIMARY KEY,
    transactionType VARCHAR(255) NOT NULL,
    accountId BIGINT NOT NULL,
    amount DECIMAL(20, 2) NOT NULL,
    description VARCHAR(255),
    transactionDate DATE NOT NULL
);

