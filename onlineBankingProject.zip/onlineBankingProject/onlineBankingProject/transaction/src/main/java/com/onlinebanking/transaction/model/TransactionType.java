package com.onlinebanking.transaction.model;



public enum TransactionType {
    DEPOSIT,
    WITHDRAWAL,
    TRANSFER
}
