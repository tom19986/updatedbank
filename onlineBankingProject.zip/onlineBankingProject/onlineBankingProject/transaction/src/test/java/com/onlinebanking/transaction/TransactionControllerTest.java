package com.onlinebanking.transaction;

import com.onlinebanking.transaction.controller.TransactionController;
import com.onlinebanking.transaction.dto.*;
import com.onlinebanking.transaction.service.TransactionService;
import com.onlinebanking.transaction.util.SuccessMessageUtil;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.data.domain.*;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.Collections;
import java.util.Objects;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
public class TransactionControllerTest {

    @Mock
    private TransactionService transactionService;

    @InjectMocks
    private TransactionController transactionController;

    private TransactionRequestDTO transactionRequestDTO;
    private TransactionResponseDTO transactionResponseDTO;
    private TransactionDateDTO transactionDateDTO;
    private TransactionSummaryDTO transactionSummaryDTO;

    @BeforeEach
    public void setUp() {
        transactionRequestDTO = new TransactionRequestDTO();
        transactionRequestDTO.setAccountId(1L);
        transactionRequestDTO.setAmount(BigDecimal.valueOf(100.00));
        transactionRequestDTO.setDescription("Test Transaction");

        transactionResponseDTO = new TransactionResponseDTO();
        transactionResponseDTO.setTransactionId(1L);
        transactionResponseDTO.setAccountId(1L);
        transactionResponseDTO.setAmount(BigDecimal.valueOf(100.00));
        transactionResponseDTO.setDescription("Test Transaction");
        transactionResponseDTO.setMessage(SuccessMessageUtil.TRANSACTION_CREATED_SUCCESSFULLY);

        transactionDateDTO =new TransactionDateDTO();
        transactionDateDTO.setStartDate(LocalDate.now().minusDays(30));
        transactionDateDTO.setEndDate(LocalDate.now());

        transactionSummaryDTO = new TransactionSummaryDTO();
        transactionSummaryDTO.setTotalAmount(BigDecimal.valueOf(100.00));
        transactionSummaryDTO.setTotalTransactions(1);
    }

    @Test
    public void testCreateTransaction_Successful() {
        when(transactionService.createTransaction(transactionRequestDTO)).thenReturn(transactionResponseDTO);
        ResponseEntity<TransactionResponseDTO> response = transactionController.createTransaction(transactionRequestDTO);
        assertEquals(HttpStatus.CREATED, response.getStatusCode());
        assertEquals(transactionResponseDTO, response.getBody());
    }

    @Test
    public void testGetTransactionById() {
        when(transactionService.getTransactionById(1L)).thenReturn(transactionResponseDTO);
        ResponseEntity<TransactionResponseDTO> response = transactionController.getTransactionById(1L);
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals(transactionResponseDTO, response.getBody());
    }

    @Test
    public void testGetAllTransactions() {
        // Prepare mock data
        TransactionResponseDTO transactionResponseDTO = new TransactionResponseDTO();
        transactionResponseDTO.setTransactionId(1L);
        transactionResponseDTO.setAccountId(1L);
        transactionResponseDTO.setAmount(BigDecimal.valueOf(100.00));
        transactionResponseDTO.setDescription("Test Transaction");

        Page<TransactionResponseDTO> transactionPage = new PageImpl<>(Collections.singletonList(transactionResponseDTO), PageRequest.of(0, 10, Sort.by("transactionDate").ascending()), 1);

        when(transactionService.getAllTransactions(0, 10, "transactionDate", "asc")).thenReturn(transactionPage);

        ResponseEntity<Page<TransactionResponseDTO>> response = transactionController.getAllTransactions(0, 10, "transactionDate", "asc");

        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals(1, response.getBody().getContent().size());
        assertEquals(BigDecimal.valueOf(100.00), response.getBody().getContent().get(0).getAmount());
    }

    @Test
    public void testGetTransactionByAccountId() {
        when(transactionService.getTransactionByAccountId(1L)).thenReturn(transactionResponseDTO);
        ResponseEntity<TransactionResponseDTO> response = transactionController.getTransactionByAccountId(1L);
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals(transactionResponseDTO, response.getBody());
    }

    @Test
    public void testDeleteTransaction() {
        when(transactionService.deleteTransaction(1L)).thenReturn(SuccessMessageUtil.TRANSACTION_DELETED_SUCCESSFULLY);

        ResponseEntity<String> response = transactionController.deleteTransaction(1L);
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals(SuccessMessageUtil.TRANSACTION_DELETED_SUCCESSFULLY, response.getBody());
    }

    @Test
    public void testGetTransactionsByDateRange() {
        TransactionResponseDTO transactionResponseDTO = new TransactionResponseDTO();
        transactionResponseDTO.setTransactionId(1L);
        transactionResponseDTO.setAccountId(1L);
        transactionResponseDTO.setAmount(BigDecimal.valueOf(100.00));
        transactionResponseDTO.setDescription("Test Transaction");

        Page<TransactionResponseDTO> transactionPage = new PageImpl<>(Collections.singletonList(transactionResponseDTO), PageRequest.of(0, 10, Sort.by("transactionDate").ascending()), 1);

        when(transactionService.getTransactionsByDateRange(transactionDateDTO, PageRequest.of(0, 10, Sort.by("transactionDate").ascending()))).thenReturn(transactionPage);

        ResponseEntity<Page<TransactionResponseDTO>> response = transactionController.getTransactionsByDateRange(transactionDateDTO, 0, 10, "transactionDate", "asc");

        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals(1, response.getBody().getContent().size());
        assertEquals(BigDecimal.valueOf(100.00), response.getBody().getContent().get(0).getAmount());
    }

    @Test
    public void testGetTransactionSummary() {
        when(transactionService.getTransactionSummary(LocalDate.now().minusDays(30), LocalDate.now())).thenReturn(transactionSummaryDTO);

        ResponseEntity<TransactionSummaryDTO> response = transactionController.getTransactionSummary(LocalDate.now().minusDays(30), LocalDate.now());
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals(transactionSummaryDTO, response.getBody());
    }
}
