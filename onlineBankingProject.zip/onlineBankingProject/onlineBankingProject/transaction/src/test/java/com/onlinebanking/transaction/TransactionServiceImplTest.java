package com.onlinebanking.transaction;

import com.onlinebanking.transaction.dto.TransactionDateDTO;
import com.onlinebanking.transaction.dto.TransactionRequestDTO;
import com.onlinebanking.transaction.dto.TransactionResponseDTO;
import com.onlinebanking.transaction.dto.TransactionSummaryDTO;
import com.onlinebanking.transaction.exception.TransactionNotFoundException;
import com.onlinebanking.transaction.model.Transaction;
import com.onlinebanking.transaction.repository.TransactionRepository;
import com.onlinebanking.transaction.service.TransactionServiceImpl;
import com.onlinebanking.transaction.util.ErrorMessageUtil;
import com.onlinebanking.transaction.util.SuccessMessageUtil;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.modelmapper.ModelMapper;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.Collections;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

public class TransactionServiceImplTest {

    @Mock
    private TransactionRepository transactionRepository;

    @Mock
    private ModelMapper modelMapper;

    @InjectMocks
    private TransactionServiceImpl transactionService;

    private Transaction transaction;
    private TransactionRequestDTO transactionRequestDTO;
    private TransactionResponseDTO transactionResponseDTO;

    @BeforeEach
    public void setUp() {
        MockitoAnnotations.openMocks(this);

        transaction = new Transaction();
        transaction.setTransactionId(1L);
        transaction.setAccountId(123L);
        transaction.setTransactionDate(LocalDate.now());
        transaction.setAmount(BigDecimal.valueOf(100.00));

        transactionRequestDTO = new TransactionRequestDTO();
        transactionRequestDTO.setAccountId(123L);
        transactionRequestDTO.setAmount(BigDecimal.valueOf(100.00));

        transactionResponseDTO = new TransactionResponseDTO();
        transactionResponseDTO.setTransactionId(1L);
        transactionResponseDTO.setAccountId(123L);
        transactionResponseDTO.setTransactionDate(LocalDate.now());
        transactionResponseDTO.setAmount(BigDecimal.valueOf(100.00));
    }

    @Test
    public void testCreateTransaction() {
        when(modelMapper.map(transactionRequestDTO, Transaction.class)).thenReturn(transaction);
        when(transactionRepository.save(transaction)).thenReturn(transaction);
        when(modelMapper.map(transaction, TransactionResponseDTO.class)).thenReturn(transactionResponseDTO);

        TransactionResponseDTO response = transactionService.createTransaction(transactionRequestDTO);

        assertEquals(SuccessMessageUtil.TRANSACTION_CREATED_SUCCESSFULLY, response.getMessage());
        assertEquals(transactionResponseDTO, response);
    }

    @Test
    public void testGetTransactionById() {
        when(transactionRepository.findByTransactionId(1L)).thenReturn(transaction);
        when(modelMapper.map(transaction, TransactionResponseDTO.class)).thenReturn(transactionResponseDTO);

        TransactionResponseDTO response = transactionService.getTransactionById(1L);

        assertEquals(transactionResponseDTO, response);
    }

    @Test
    public void testGetTransactionByIdNotFound() {
        when(transactionRepository.findByTransactionId(1L)).thenReturn(null);

        assertThrows(TransactionNotFoundException.class, () -> {
            transactionService.getTransactionById(1L);
        });
    }

    @Test
    public void testGetTransactionByAccountId() {
        when(transactionRepository.findByAccountId(123L)).thenReturn(transaction);
        when(modelMapper.map(transaction, TransactionResponseDTO.class)).thenReturn(transactionResponseDTO);

        TransactionResponseDTO response = transactionService.getTransactionByAccountId(123L);

        assertEquals(transactionResponseDTO, response);
    }

    @Test
    public void testGetTransactionByAccountIdNotFound() {
        when(transactionRepository.findByAccountId(123L)).thenReturn(null);

        assertThrows(TransactionNotFoundException.class, () -> {
            transactionService.getTransactionByAccountId(123L);
        });
    }

    @Test
    public void testGetAllTransactions() {
        List<Transaction> transactions = Collections.singletonList(transaction);
        when(transactionRepository.findAll()).thenReturn(transactions);
        when(modelMapper.map(transaction, TransactionResponseDTO.class)).thenReturn(transactionResponseDTO);

        List<TransactionResponseDTO> responses = transactionService.getAllTransactions();

        assertEquals(1, responses.size());
        assertEquals(transactionResponseDTO, responses.get(0));
    }

    @Test
    public void testGetAllTransactionsWithPagination() {
        Pageable pageable = PageRequest.of(0, 10, Sort.by("transactionDate").descending());
        Page<Transaction> transactionPage = new PageImpl<>(Collections.singletonList(transaction), pageable, 1);
        when(transactionRepository.findAll(pageable)).thenReturn(transactionPage);
        when(modelMapper.map(transaction, TransactionResponseDTO.class)).thenReturn(transactionResponseDTO);

        Page<TransactionResponseDTO> responsePage = transactionService.getAllTransactions(0, 10, "transactionDate", "desc");

        assertEquals(1, responsePage.getTotalElements());
        assertEquals(transactionResponseDTO, responsePage.getContent().get(0));
    }

    @Test
    public void testDeleteTransaction() {
        when(transactionRepository.findByTransactionId(1L)).thenReturn(transaction);

        String message = transactionService.deleteTransaction(1L);

        assertEquals(SuccessMessageUtil.TRANSACTION_DELETED_SUCCESSFULLY, message);
        verify(transactionRepository).delete(transaction);
    }

    @Test
    public void testDeleteTransactionNotFound() {
        when(transactionRepository.findByTransactionId(1L)).thenReturn(null);

        assertThrows(TransactionNotFoundException.class, () -> {
            transactionService.deleteTransaction(1L);
        });
    }

    @Test
    public void testGetTransactionsByDateRange() {
        LocalDate startDate = LocalDate.now().minusDays(7);
        LocalDate endDate = LocalDate.now();
        Pageable pageable = PageRequest.of(0, 10, Sort.by("transactionDate").descending());
        Page<Transaction> transactionPage = new PageImpl<>(Collections.singletonList(transaction), pageable, 1);
        when(transactionRepository.findByTransactionDateBetween(startDate, endDate, pageable)).thenReturn(transactionPage);
        when(modelMapper.map(transaction, TransactionResponseDTO.class)).thenReturn(transactionResponseDTO);

        Page<TransactionResponseDTO> responsePage = transactionService.getTransactionsByDateRange(new TransactionDateDTO(startDate, endDate), pageable);

        assertEquals(1, responsePage.getTotalElements());
        assertEquals(transactionResponseDTO, responsePage.getContent().get(0));
    }

    @Test
    public void testGetTransactionSummary() {
        LocalDate startDate = LocalDate.now().minusDays(7);
        LocalDate endDate = LocalDate.now();
        List<Transaction> transactions = Collections.singletonList(transaction);
        when(transactionRepository.findByTransactionDateBetween(startDate, endDate)).thenReturn(transactions);

        TransactionSummaryDTO summaryDTO = new TransactionSummaryDTO(BigDecimal.valueOf(100.00), 1);
        TransactionSummaryDTO response = transactionService.getTransactionSummary(startDate, endDate);

        assertEquals(summaryDTO.getTotalAmount(), response.getTotalAmount());
        assertEquals(summaryDTO.getTotalTransactions(), response.getTotalTransactions());
    }
}
