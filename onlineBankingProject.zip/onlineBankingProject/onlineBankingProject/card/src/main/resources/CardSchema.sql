-- SQL script to create the 'cards' table

CREATE TABLE cards (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    card_number VARCHAR(255) NOT NULL UNIQUE,
    cardHolderName VARCHAR(255) NOT NULL,
    expiryDate TIMESTAMP,
    cvv VARCHAR(10),
    pin VARCHAR(10),
    card_type VARCHAR(255) NOT NULL,
    status VARCHAR(255) NOT NULL,
    balance DECIMAL(20, 2) NOT NULL DEFAULT 0.00,
    created_date TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    last_updated_date TIMESTAMP,
    lastUsedDate TIMESTAMP,
    accountId BIGINT NOT NULL
);

