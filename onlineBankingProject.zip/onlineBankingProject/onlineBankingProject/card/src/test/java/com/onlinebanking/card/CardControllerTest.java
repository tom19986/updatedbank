package com.onlinebanking.card;

import com.onlinebanking.card.controller.CardController;
import com.onlinebanking.card.dto.CardRequestDTO;
import com.onlinebanking.card.dto.CardResponseDTO;
import com.onlinebanking.card.model.CardStatus;
import com.onlinebanking.card.model.CardType;
import com.onlinebanking.card.service.CardService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.Collections;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

public class CardControllerTest {

    @Mock
    private CardService cardService;

    @InjectMocks
    private CardController cardController;

    private MockMvc mockMvc;

    private CardRequestDTO cardRequestDTO;
    private CardResponseDTO cardResponseDTO;

    @BeforeEach
    public void setup() {
        MockitoAnnotations.openMocks(this);
        mockMvc = MockMvcBuilders.standaloneSetup(cardController).build();

        // Initialize test data
        cardRequestDTO = new CardRequestDTO();
        cardRequestDTO.setCardNumber("1234567890123456");
        cardRequestDTO.setCardHolderName("tom");
        cardRequestDTO.setExpiryDate(LocalDateTime.now());  // Ensure the date format matches the controller's expected format
        cardRequestDTO.setCardType(CardType.DEBIT);
        cardRequestDTO.setStatus(CardStatus.ACTIVE);
        cardRequestDTO.setPin("1234");
        cardRequestDTO.setCvv("123");
        cardRequestDTO.setInitialBalance(BigDecimal.valueOf(100));
        cardRequestDTO.setAccountId(1L);


    }

    @Test
    public void testCreateCard() throws Exception {
        cardResponseDTO = new CardResponseDTO();
        cardResponseDTO.setMessage("Card created successfully.");
        // Mock service call
        when(cardService.createCard(any(CardRequestDTO.class))).thenReturn(cardResponseDTO);

        // Perform the request and verify the response
        mockMvc.perform(post("/api/cards")
                        .contentType("application/json")
                        .content("{ \"cardNumber\": \"1234567890123456\", \"cardHolderName\": \"tom\", \"expirationDate\": \"2025-12-31\", \"cardType\": \"DEBIT\", \"status\": \"ACTIVE\", \"pin\": \"1234\", \"cvv\": \"123\", \"initialBalance\": 100, \"accountId\": 1 }"))
                .andExpect(status().isOk())
                .andExpect(content().json("{ \"message\": \"Card created successfully.\" }"));  // Adjust this according to the actual response
    }

    @Test
    public void testDeleteCard() throws Exception {
        when(cardService.deleteCard(anyString())).thenReturn("Card deleted successfully");

        mockMvc.perform(delete("/api/cards/{cardNumber}", "1234567890"))
                .andExpect(status().isOk())
                .andExpect(content().string("Card deleted successfully"));
    }

    @Test
    public void testGetCardByCriteria() throws Exception {
        cardResponseDTO = new CardResponseDTO();
        cardResponseDTO.setMessage("Card found successfully.");
        // Prepare mock data
        Long id = 1L;
        String cardNumber = "1234567890123456";
        String cardHolderName = "tom";
        Long accountId = 1L;

        // Mock service call
        when(cardService.getCardByCriteria(id, cardNumber, cardHolderName, accountId)).thenReturn(cardResponseDTO);

        // Perform the request and verify the response
        mockMvc.perform(get("/api/cards/search")
                        .param("id", id.toString())
                        .param("cardNumber", cardNumber)
                        .param("cardHolderName", cardHolderName)
                        .param("accountId", accountId.toString()))
                .andExpect(status().isOk())
                .andExpect(content().json("{ \"message\": \"Card found successfully.\" }"));
    }

    @Test
    public void testGetCardByCriteria_BadRequest() throws Exception {
        // Perform the request with no parameters and expect a bad request status
        mockMvc.perform(get("/api/cards/search"))
                .andExpect(status().isBadRequest())
                .andExpect(content().string("At least one search criteria must be provided."));
    }

    @Test
    public void testGetCardsByCriteria_ValidParameters() throws Exception {
        // Prepare mock data
        CardResponseDTO cardResponseDTO = new CardResponseDTO();
        cardResponseDTO.setCardNumber("9390250844501015");
        cardResponseDTO.setCardHolderName("tom");
        cardResponseDTO.setExpiryDate(LocalDateTime.of(2026, 9, 5, 18, 53, 30));
        cardResponseDTO.setCardType(CardType.DEBIT);
        cardResponseDTO.setStatus(CardStatus.ACTIVE);
        cardResponseDTO.setBalance(BigDecimal.valueOf(100.00));
        cardResponseDTO.setAccountId(1L);

        Page<CardResponseDTO> cardPage = new PageImpl<>(List.of(cardResponseDTO), PageRequest.of(0, 10), 1);

        // Mock the service call
        when(cardService.getCardsByCriteria(
                eq("tom"),
                eq("9390250844501015"),
                anyList(),
                anyList(),
                any(Pageable.class))
        ).thenReturn(cardPage);

        // Perform the request and verify the response
        mockMvc.perform(get("/api/cards/searchList")
                        .param("cardHolderName", "tom")
                        .param("cardNumber", "9390250844501015")
                        .param("cardStatus", "ACTIVE")
                        .param("cardType", "DEBIT")
                        .param("page", "0")
                        .param("size", "10")
                        .param("sortBy", "cardNumber")
                        .param("sortDir", "asc"))
                .andExpect(status().isOk());
//                .andExpect(content().json("""
//            {
//                "content": [
//                    {
//                        "cardNumber": "9390250844501015",
//                        "cardHolderName": "tom",
//                        "expiryDate": "2026-09-05T18:53:30.79494",
//                        "cardType": "DEBIT",
//                        "status": "ACTIVE",
//                        "balance": 100.00,
//                        "accountId": 1,
//                        "message": null
//                    }
//                ],
//                "pageable": {
//                    "pageNumber": 0,
//                    "pageSize": 10,
//                    "sort": {
//                        "empty": false,
//                        "sorted": true,
//                        "unsorted": false
//                    },
//                    "offset": 0,
//                    "paged": true,
//                    "unpaged": false
//                },
//                "last": true,
//                "totalPages": 1,
//                "totalElements": 1,
//                "size": 10,
//                "number": 0,
//                "sort": {
//                    "empty": false,
//                    "sorted": true,
//                    "unsorted": false
//                },
//                "first": true,
//                "numberOfElements": 1,
//                "empty": false
//            }
//            """));
    }




}
