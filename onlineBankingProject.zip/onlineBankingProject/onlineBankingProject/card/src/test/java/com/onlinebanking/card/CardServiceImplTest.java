package com.onlinebanking.card;

import com.onlinebanking.card.dto.CardResponseDTO;
import com.onlinebanking.card.model.Card;
import com.onlinebanking.card.model.CardStatus;
import com.onlinebanking.card.model.CardType;
import com.onlinebanking.card.repository.CardRepository;
import com.onlinebanking.card.service.CardServiceImpl;

import com.onlinebanking.card.service.GetCardService;
import com.onlinebanking.card.util.SuccessMessageUtil;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.modelmapper.ModelMapper;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.Pageable;

import java.time.LocalDateTime;
import java.util.Collections;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
public class CardServiceImplTest {

    @Mock
    private CardRepository cardRepository;

    @Mock
    private ModelMapper modelMapper;

    @InjectMocks
    private CardServiceImpl cardService;
    @Mock
    private GetCardService getCardService;

    private Card card;
    private CardResponseDTO cardResponseDTO;

    @BeforeEach
    void setUp() {
        card = new Card();
        card.setId(1L);
        card.setCardNumber("1234567890123456");
        card.setCardHolderName("John Doe");
        card.setCardType(CardType.CREDIT);
        card.setStatus(CardStatus.ACTIVE);
        card.setCreatedDate(LocalDateTime.now());

        cardResponseDTO = new CardResponseDTO();

        cardResponseDTO.setCardNumber("1234567890123456");
        cardResponseDTO.setCardHolderName("John Doe");
        cardResponseDTO.setStatus(CardStatus.ACTIVE);
        cardResponseDTO.setMessage(SuccessMessageUtil.CARD_CREATED_SUCCESSFULLY);
    }

    @Test
    void testDeactivateCard() {
        when(getCardService.getByCardNumber(anyString())).thenReturn(card);
        when(cardRepository.save(any(Card.class))).thenReturn(card);
        when(modelMapper.map(any(Card.class), eq(CardResponseDTO.class))).thenReturn(cardResponseDTO);
        CardResponseDTO responseDTO = cardService.deactivateCard("1234567890123456");
        assertNotNull(responseDTO);
        assertEquals(SuccessMessageUtil.CARD_DEACTIVATED_SUCCESSFULLY, responseDTO.getMessage());
 }

    @Test
    void testGetCardByCardNumber() {
        when(getCardService.getByCardNumber(anyString())).thenReturn(card);
        when(modelMapper.map(card, CardResponseDTO.class)).thenReturn(cardResponseDTO);

        CardResponseDTO responseDTO = cardService.getCardByCriteria(null, "1234567890123456", null, null);

        assertNotNull(responseDTO);
        assertEquals("1234567890123456", responseDTO.getCardNumber());
    }

    @Test
    void testGetCardByHolderName() {
        when(getCardService.getByCardHolderName(anyString())).thenReturn(card);
        when(modelMapper.map(card, CardResponseDTO.class)).thenReturn(cardResponseDTO);

        CardResponseDTO responseDTO = cardService.getCardByCriteria(null, null, "John Doe", null);

        assertNotNull(responseDTO);
        assertEquals("John Doe", responseDTO.getCardHolderName());
    }

    @Test
    void testGetCardsByStatus() {
        Page<Card> cardPage = new PageImpl<>(Collections.singletonList(card));
        when(cardRepository.findByStatusIn(anyList(), any(Pageable.class))).thenReturn(cardPage);
        when(modelMapper.map(any(Card.class), eq(CardResponseDTO.class))).thenReturn(cardResponseDTO);

        Page<CardResponseDTO> responseDTOPage = cardService.getCardsByCriteria(null,null, Collections.singletonList(CardStatus.ACTIVE),null,Pageable.unpaged());

        assertNotNull(responseDTOPage);
        assertEquals(1, responseDTOPage.getTotalElements());
        assertEquals("1234567890123456", responseDTOPage.getContent().get(0).getCardNumber());
    }



    @Test
    void testDeleteCardByCardNumber() {
        when(getCardService.getByCardNumber(anyString())).thenReturn(card);
        doNothing().when(cardRepository).delete(any(Card.class));

        String message = cardService.deleteCard("1234567890123456");

        assertEquals(SuccessMessageUtil.CARD_DELETED_SUCCESSFULLY, message);
    }
    @Test
    void testGetAllCards() {
        Page<Card> cardPage = new PageImpl<>(Collections.singletonList(card));
        when(cardRepository.findAll(any(Pageable.class))).thenReturn(cardPage);
        when(modelMapper.map(any(Card.class), eq(CardResponseDTO.class))).thenReturn(cardResponseDTO);

        Page<CardResponseDTO> responseDTOPage = cardService.getAllCards(Pageable.unpaged());

        assertNotNull(responseDTOPage);
        assertEquals(1, responseDTOPage.getTotalElements());
        assertEquals("1234567890123456", responseDTOPage.getContent().get(0).getCardNumber());
    }
}
