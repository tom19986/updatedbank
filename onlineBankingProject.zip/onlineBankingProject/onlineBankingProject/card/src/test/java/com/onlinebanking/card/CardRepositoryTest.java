package com.onlinebanking.card;

import com.onlinebanking.card.model.Card;
import com.onlinebanking.card.model.CardStatus;
import com.onlinebanking.card.model.CardType;
import com.onlinebanking.card.repository.CardRepository;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.data.domain.PageRequest;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;


import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertNotNull;

//@DataJpaTest
public class CardRepositoryTest {

    @Autowired
    private CardRepository cardRepository;

    @Test
    public void testFindByCardNumber() {
        Card card = new Card();
        card.setId(1L);
        card.setCardNumber("1234567890");
        card.setCardHolderName("John Doe");
        card.setBalance(BigDecimal.valueOf(1000));
        card.setCardType(CardType.CREDIT);
        card.setCreatedDate(LocalDateTime.now());
        //card.setExpiryDate(LocalDate.now().plusYears(1).atStartOfDay());
        card.setStatus(CardStatus.ACTIVE);
        cardRepository.save(card);

        Card foundCard = cardRepository.findByCardNumber("1234567890");
        assertNotNull(foundCard);
       // assertThat(foundCard.getCardHolderName()).isEqualTo("John Doe");
    }
}
