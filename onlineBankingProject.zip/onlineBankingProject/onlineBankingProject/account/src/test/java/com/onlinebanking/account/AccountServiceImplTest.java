package com.onlinebanking.account;

import com.onlinebanking.account.dto.AccountRequestDTO;
import com.onlinebanking.account.dto.AccountResponseDTO;
import com.onlinebanking.account.model.Account;
import com.onlinebanking.account.model.AccountStatus;
import com.onlinebanking.account.model.AccountType;
import com.onlinebanking.account.repository.AccountRepository;
import com.onlinebanking.account.service.AccountServiceImpl;
import com.onlinebanking.account.util.SuccessMessageConstants;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.modelmapper.ModelMapper;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.Pageable;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.Collections;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
public class AccountServiceImplTest {

    @Mock
    private AccountRepository accountRepository;

    @Mock
    private ModelMapper modelMapper;

    @InjectMocks
    private AccountServiceImpl accountService;

    private Account account;
    private AccountRequestDTO accountRequestDTO;
    private AccountResponseDTO accountResponseDTO;

    @BeforeEach
    void setUp() {
        account = new Account();
        account.setId(1L);
        account.setAccountNumber("MOB36050001");
        account.setAccountHolderName("John Doe");
        account.setBalance(BigDecimal.valueOf(100));
        account.setStatus(AccountStatus.ACTIVE);
        account.setAccountType(AccountType.SAVINGS);
        account.setCreatedDate(LocalDateTime.now());

        accountRequestDTO = new AccountRequestDTO();
        accountRequestDTO.setAccountNumber("MOB36050001");
        accountRequestDTO.setAccountHolderName("tom");
        accountRequestDTO.setAccountType("SAVINGS");
        accountRequestDTO.setBalance(BigDecimal.valueOf(500));
        accountRequestDTO.setAddAmount(BigDecimal.valueOf(100));
        accountRequestDTO.setCurrency("USD");
        accountRequestDTO.setUserId(1L);
        accountRequestDTO.setStatus(String.valueOf(AccountStatus.PENDING));

        accountResponseDTO = new AccountResponseDTO();
        accountResponseDTO.setId(1L);
        accountResponseDTO.setAccountNumber("MOB36050001");
        accountResponseDTO.setAccountHolderName("tom");
        accountResponseDTO.setBalance(BigDecimal.valueOf(500));
        accountResponseDTO.setStatus(AccountStatus.PENDING);
        accountResponseDTO.setMessage(SuccessMessageConstants.ACCOUNT_CREATED_SUCCESS);
   }

    @Test
    void testCreateAccount() {
        when(modelMapper.map(accountRequestDTO, Account.class)).thenReturn(account);
        when(accountRepository.save(account)).thenReturn(account);
        when(modelMapper.map(account, AccountResponseDTO.class)).thenReturn(accountResponseDTO);

        AccountResponseDTO responseDTO = accountService.createAccount(accountRequestDTO);

        assertNotNull(responseDTO);
        assertEquals(SuccessMessageConstants.ACCOUNT_CREATED_SUCCESS, responseDTO.getMessage());

        verify(accountRepository, times(1)).save(any(Account.class));
        verify(modelMapper, times(1)).map(accountRequestDTO, Account.class);
        verify(modelMapper, times(1)).map(account, AccountResponseDTO.class);
    }

    @Test
    void testGetAccountByCriteria_ById() {
        when(accountRepository.findById(anyLong())).thenReturn(java.util.Optional.of(account));
        when(modelMapper.map(account, AccountResponseDTO.class)).thenReturn(accountResponseDTO);

        AccountResponseDTO responseDTO = accountService.getAccountByCriteria(1L, null, null, null);

        assertNotNull(responseDTO);
        assertEquals("MOB36050001", responseDTO.getAccountNumber());
    }

@Test
public void testGetAccountByCriteria_ByAccountNumber() {
    when(accountRepository.findByAccountNumber("MOB36050001")).thenReturn(account);
    when(modelMapper.map(account, AccountResponseDTO.class)).thenReturn(accountResponseDTO);

    AccountResponseDTO response = accountService.getAccountByCriteria(null, "MOB36050001", null, null);

    assertNotNull(response);
    assertEquals("tom", response.getAccountHolderName());
}

    @Test
    void testGetAccountByCriteria_ByAccountHolderName() {
        when(accountRepository.findByAccountHolderName(anyString())).thenReturn(account);
        when(modelMapper.map(account, AccountResponseDTO.class)).thenReturn(accountResponseDTO);

        AccountResponseDTO responseDTO = accountService.getAccountByCriteria(null, null, "John Doe", null);

        assertNotNull(responseDTO);
        assertEquals("MOB36050001", responseDTO.getAccountNumber());
    }

    @Test
    void testGetAccountByCriteria_ByUserId() {
        when(accountRepository.findByUserId(anyLong())).thenReturn(account);
        when(modelMapper.map(account, AccountResponseDTO.class)).thenReturn(accountResponseDTO);

        AccountResponseDTO responseDTO = accountService.getAccountByCriteria(null, null, null, 1L);

        assertNotNull(responseDTO);
        assertEquals("tom", responseDTO.getAccountHolderName());
    }

    @Test
    void testChangeAccountType() {
        when(accountRepository.findByAccountNumber(anyString())).thenReturn(account);
        when(accountRepository.save(any(Account.class))).thenReturn(account);
        when(modelMapper.map(account, AccountResponseDTO.class)).thenReturn(accountResponseDTO);

        AccountResponseDTO responseDTO = accountService.changeAccountType("MOB36050001", "SAVINGS");

        assertNotNull(responseDTO);
        //assertEquals(AccountType.SAVINGS, responseDTO.getAccountType());
        assertEquals(SuccessMessageConstants.TYPE_UPDATE_MSG(AccountType.SAVINGS), responseDTO.getMessage());
    }

    @Test
    void testChangeAccountStatus() {
        when(accountRepository.findByAccountNumber(anyString())).thenReturn(account);
        when(accountRepository.save(any(Account.class))).thenReturn(account);
        when(modelMapper.map(account, AccountResponseDTO.class)).thenReturn(accountResponseDTO);

        AccountResponseDTO responseDTO = accountService.changeAccountStatus(accountRequestDTO.getAccountNumber(), accountRequestDTO.getStatus());

        assertNotNull(responseDTO);
        assertEquals(AccountStatus.PENDING, responseDTO.getStatus());
        assertEquals(SuccessMessageConstants.STATUS_UPDATE_MSG(AccountStatus.PENDING), responseDTO.getMessage());
    }

    @Test
    void testDeleteAccountByAccountNumber() {
        when(accountRepository.findByAccountNumber(anyString())).thenReturn(account);
        doNothing().when(accountRepository).delete(any(Account.class));

        String message = accountService.deleteAccountByAccountNumber("MOB36050001");

        assertEquals(SuccessMessageConstants.ACCOUNT_DELETED_SUCCESS, message);
    }

    @Test
    void testSetBalance() {
        // Arrange
        BigDecimal newBalance = BigDecimal.valueOf(600);
        account.setBalance(newBalance); // Update the balance in the mock account object
        accountResponseDTO.setBalance(newBalance); // Update the expected balance in the response DTO

        when(accountRepository.findByAccountNumber(anyString())).thenReturn(account);
        when(accountRepository.save(any(Account.class))).thenReturn(account);
        when(modelMapper.map(account, AccountResponseDTO.class)).thenReturn(accountResponseDTO);

        // Act
        AccountResponseDTO responseDTO = accountService.setBalance("MOB36050001", newBalance);

        // Assert
        assertNotNull(responseDTO);
        assertEquals(newBalance, responseDTO.getBalance()); // Assert the updated balance
        assertEquals(SuccessMessageConstants.BALANCE_UPDATED, responseDTO.getMessage());
    }


    @Test
    void testActivateBankAccount() {
        // Arrange
        Account updatedAccount = new Account(); // Create a new instance or copy of the account for updated status
        updatedAccount.setId(1L);
        updatedAccount.setAccountNumber("MOB36050001");
        updatedAccount.setAccountHolderName("John Doe");
        updatedAccount.setBalance(BigDecimal.valueOf(100));
        updatedAccount.setStatus(AccountStatus.PENDING); // Ensure the status is ACTIVE
        updatedAccount.setAccountType(AccountType.SAVINGS);
        updatedAccount.setCreatedDate(LocalDateTime.now());

        AccountResponseDTO updatedAccountResponseDTO = new AccountResponseDTO();
        updatedAccountResponseDTO.setId(1L);
        updatedAccountResponseDTO.setAccountNumber("MOB36050001");
        updatedAccountResponseDTO.setAccountHolderName("John Doe");
        updatedAccountResponseDTO.setBalance(BigDecimal.valueOf(100));
        updatedAccountResponseDTO.setStatus(AccountStatus.ACTIVE); // Ensure status is ACTIVE
        updatedAccountResponseDTO.setMessage(SuccessMessageConstants.ACCOUNT_ACTIVATED);

        when(accountRepository.findByAccountNumber(anyString())).thenReturn(updatedAccount);
        when(accountRepository.save(any(Account.class))).thenReturn(updatedAccount);
        when(modelMapper.map(updatedAccount, AccountResponseDTO.class)).thenReturn(updatedAccountResponseDTO);

        // Act
        AccountResponseDTO responseDTO = accountService.activateBankAccount("MOB36050001");

        // Assert
        assertNotNull(responseDTO);
        assertEquals(AccountStatus.ACTIVE, responseDTO.getStatus());
        assertEquals(SuccessMessageConstants.ACCOUNT_ACTIVATED, responseDTO.getMessage());
    }


    @Test
    void testAddAmount() {
        when(accountRepository.findByAccountNumber(anyString())).thenReturn(account);
        when(accountRepository.save(any(Account.class))).thenReturn(account);
        when(modelMapper.map(account, AccountResponseDTO.class)).thenReturn(accountResponseDTO);

        AccountResponseDTO responseDTO = accountService.AddAmount("MOB36050001", BigDecimal.valueOf(100));

        assertNotNull(responseDTO);
        //assertEquals(BigDecimal.valueOf(600), responseDTO.getBalance());
        assertEquals(SuccessMessageConstants.BALANCE_UPDATED, responseDTO.getMessage());
    }

    @Test
    void testGetAllAccounts() {
        // Arrange
        Page<Account> accountPage = new PageImpl<>(Collections.singletonList(account)); // Mock the repository response
        AccountResponseDTO accountResponseDTO = new AccountResponseDTO();
        accountResponseDTO.setId(1L);
        accountResponseDTO.setAccountNumber("MOB36050001");
        accountResponseDTO.setAccountHolderName("John Doe");
        accountResponseDTO.setBalance(BigDecimal.valueOf(100));
        accountResponseDTO.setStatus(AccountStatus.ACTIVE); // Ensure correct status
        accountResponseDTO.setMessage(SuccessMessageConstants.ACCOUNT_CREATED_SUCCESS);

        when(accountRepository.findAll(any(Pageable.class))).thenReturn(accountPage);
        when(modelMapper.map(any(Account.class), eq(AccountResponseDTO.class))).thenReturn(accountResponseDTO);

        // Act
        Page<AccountResponseDTO> responseDTOPage = accountService.getAllAccounts(Pageable.unpaged());

        // Assert
        assertNotNull(responseDTOPage);
        assertEquals(1, responseDTOPage.getTotalElements());
        assertEquals("John Doe", responseDTOPage.getContent().get(0).getAccountHolderName());
        assertEquals("MOB36050001", responseDTOPage.getContent().get(0).getAccountNumber());
        assertEquals(BigDecimal.valueOf(100), responseDTOPage.getContent().get(0).getBalance());
        assertEquals(AccountStatus.ACTIVE, responseDTOPage.getContent().get(0).getStatus());
    }


    @Test
    void testGetAccountsByCriteria() {
        Page<Account> accountPage = new PageImpl<>(Collections.singletonList(account));
        when(accountRepository.findByAccountHolderNameContainingIgnoreCase(anyString(), any(Pageable.class))).thenReturn(accountPage);
        when(modelMapper.map(any(Account.class), eq(AccountResponseDTO.class))).thenReturn(accountResponseDTO);

        Page<AccountResponseDTO> responseDTOPage = accountService.getAccountsByCriteria("John Doe", null, null, Pageable.unpaged());

        assertNotNull(responseDTOPage);
        assertEquals(1, responseDTOPage.getTotalElements());
        assertEquals("MOB36050001", responseDTOPage.getContent().get(0).getAccountNumber());
    }
}
