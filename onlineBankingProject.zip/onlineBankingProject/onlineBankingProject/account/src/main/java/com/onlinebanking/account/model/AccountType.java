package com.onlinebanking.account.model;

public enum AccountType {
    SAVINGS,
    CURRENT

}
